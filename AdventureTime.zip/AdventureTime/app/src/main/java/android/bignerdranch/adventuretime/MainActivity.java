package android.bignerdranch.adventuretime;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;

import org.w3c.dom.Text;

import java.util.Random;
import java.lang.Math;
import java.util.Stack;

public class MainActivity extends AppCompatActivity {
    public Button choice1;
    public Button choice2;
    public Button choice3;
    public Button choice4;
    public Button restart;
    private Button start;
    private Button next;
    public int sceneNum;
    public int textNum;
    public TextView questionText;
    public TextView nameText;
    public String username;
    private TextView welcomeText;
    private TextView scoreText;
    private TextView resultText;



        final String[][] texts_Scene1 = new String[][]{
                {"Ferb, I know what we're gonna do today!", "Phineas"},
                {"*silence*", "Ferb"},
                {"Mars is a great idea! Let's teleport ourselves to Mars!", "Phineas"}
        };

        final String[][] texts_Scene2 = new String[][]{
                {"It was hard work, but we made the portal! This should take us straight to Mars. Ready?", "Phineas"},
                {"*silence*", "Ferb"},
                {"Let's go!", "Phineas"},
                {"Woosh!", "Ferb"}
        };

        final String[][] texts_Scene3 = new String[][]{
                {"Weird. I didn't think Mars would be so... Green?", "Phineas"},
                {"Yeah.", "Ferb"},
                {"Well, it still looks cool. Let's go explore!", "Phineas"}
        };

    final String[] texts_Forest = new String[]{
            "Oh, there's a person here! Hey!",
            "Oh, hey. Who are you?",
            "I'm Phineas, and this is my brother Ferb. Is this Mars?",
            "What the what? This is Ooo.",
            "Ooo?",
            "Yeah!",
            "Oh Okay.",
            "Well, wanna go play a game?",
            "Yeah! Let's go Ferb!"
    };

    final String[] texts_Candy = new String[]{
            "I didn't think Mars was made out of candy. Weird.",
            "I don't know what Mars is, but this is the candy kingdom. I'm Princess Bubblegum.",
            "Oh well that explains a lot! Like the candy people.",
            "Yeah.",
            "Let me show you around!",
            "Finn and Jake show up.",
            "Hey PB! Who are your friends?",
            "Oh I have no idea who these guys are.",
            "I'm Phineas, and this is my brother Ferb.",
            "Well. Wanna go play a game?",
            "Yeah! Let's go Ferb!"
    };

    final String[] texts_Ice = new String[]{
            "It's so cold!",
            "Yeah, I thought Mars would be.",
            "Hey! Who are you guys! Get away from my castle!",
            "Hey, we were just trying to explore Mars.",
            "You were just trying to steal my princesses! *zap*",
            "Hey! Let us go!",
            "*Fly in from the side* Let them go, you son of a *** ***!",
            "Thank you!",
            "Who is that jerk?",
            "Ice King! He's like, evil. He kidnaps princesses. We gotta beat the glob out of him!"
    };

    final String[] texts_caves = new String[]{
            "The caves on Mars are much scarier than the ones on Earth.",
            "And dark.",
            "I will command a great and terrible army, and we will sail to a billion worlds.",
            "We will sail until every light has been extinguished.",
            "You are strong, child, but I am beyond strength. I am the end, and I have come for you."
    };



    private int messageResId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //title screen
        welcomeText = (TextView) findViewById(R.id.welcome_text);
        //nameText = (TextView) findViewById(R.id.nameText);
        resultText = (TextView) findViewById(R.id.result_text);


        start = (Button) findViewById(R.id.start_button);
        start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //start  the quiz

                startQuiz();
            }
        });
    }


    private void startQuiz() {
        resultText.findViewById(R.id.result_text).setVisibility(View.GONE);
        welcomeText.findViewById(R.id.welcome_text).setVisibility(View.GONE);
        start.findViewById(R.id.start_button).setVisibility(View.GONE);

        //go through scenes first
        questionText = (TextView) findViewById(R.id.question_text_view);
        questionText.findViewById(R.id.question_text_view).setVisibility(View.VISIBLE);
        sceneNum = 0; //keeps track of the first three scenes when they're pulled in Next().
        next = (Button) findViewById(R.id.next_button);
        next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);//********************
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(sceneNum==0){
                    displayIntro(texts_Scene1);
                }
                if(sceneNum==1){ //replace this w something more efficient...
                    displayIntro(texts_Scene2);
                }
                else if(sceneNum==2){
                    displayIntro(texts_Scene3);
                }
                else if(sceneNum>2 && sceneNum<9){
                    startButtons(texts_Forest, texts_Candy, texts_Ice, texts_caves);
                }
                //10=forest
                //11=candy
                //12=ice
                //13=caves
                else if(sceneNum==10){//indicator that we're in
                    displayGameText(texts_Forest);
                }
                else if(sceneNum==11){
                    displayGameText(texts_Candy);
                }
                else if(sceneNum==12){
                    displayGameText(texts_Ice);
                }
                else if(sceneNum==13){
                    displayGameText(texts_caves);
                }
            }
        });
        next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
        displayIntro(texts_Scene1);
        if(sceneNum>2){ //checks if we've reached the end of the introduction
            startButtons(texts_Forest, texts_Candy, texts_Ice, texts_caves);
        }
    };


        public void displayIntro(String[][] texts) {
            if(textNum == texts.length) { //if we've reached the end of this scene ->
                sceneNum++; //advance to the next scene
                textNum=0; //reset textNum so we can move through the next scene array
            }
            else{
                questionText.setText(texts[textNum][0]); //always 0 because [1] is the user
                if(texts[textNum][1] == "Phineas"){

                }
                textNum++;
            };
        };

        public void displayGameText(String [] texts){ //updates the text on the screen.
            if(textNum<texts.length) {
                questionText.setText(texts[textNum]);
                textNum++;
            }
            else if(textNum==texts.length){
                next.findViewById(R.id.next_button).setVisibility(View.GONE);
                questionText.setText("END!");
            }
        }


        //************** Choices *****************


//******************* Create buttons

        private void startButtons(final String[] texts_Forest, final String[] texts_Candy, final String [] texts_Ice, final String [] texts_caves){

            next.findViewById(R.id.next_button).setVisibility(View.GONE);
            questionText.setText("Where should we head off to? Looks like there's four paths.");

            final Button[] buttons = new Button[4];

            choice1 = (Button) findViewById(R.id.choice1_button);
            choice1.findViewById(R.id.choice1_button).setVisibility(View.VISIBLE);
            choice1.setText("Go to the Forest");
            buttons[0] = choice1;
            choice1.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    enterForest(texts_Forest);
                }
            });

            choice2 = (Button) findViewById(R.id.choice2_button);
            choice2.findViewById(R.id.choice2_button).setVisibility(View.VISIBLE);
            choice2.setText("Go to the Candy Castle");
            buttons[1] = choice2;
            choice2.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    enterCandy(texts_Candy);
                }
            });

            choice3 = (Button) findViewById(R.id.choice3_button);
            choice3.findViewById(R.id.choice3_button).setVisibility(View.VISIBLE);
            choice3.setText("Go to the Ice Mountain");
            buttons[2] = choice3;
            choice3.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    enterIce(texts_Ice);
                }
            });

            choice4 = (Button) findViewById(R.id.choice4_button);
            choice4.findViewById(R.id.choice4_button).setVisibility(View.VISIBLE);
            choice1.setText("Go to the Lich's Cave");
            buttons[3] = choice4;
            choice4.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    entercaves(texts_caves);
                }
            });

            restart = (Button) findViewById(R.id.restart_button);
            restart.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    startQuiz();
                }
            });
        };

        private void enterForest(final String [] texts_Forest){
            next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
            choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
            choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
            choice3.findViewById(R.id.choice3_button).setVisibility(View.GONE);
            choice4.findViewById(R.id.choice4_button).setVisibility(View.GONE);
            textNum=0;
            sceneNum=10;
            questionText.setText(texts_Forest[textNum]);
        }

        private void enterCandy(final String [] texts_Candy){
            next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
            choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
            choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
            choice3.findViewById(R.id.choice3_button).setVisibility(View.GONE);
            choice4.findViewById(R.id.choice4_button).setVisibility(View.GONE);
            textNum=0;
            sceneNum=11;
            questionText.setText(texts_Candy[textNum]);
        }

        private void enterIce(final String [] texts_Ice){
            next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
            choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
            choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
            choice3.findViewById(R.id.choice3_button).setVisibility(View.GONE);
            choice4.findViewById(R.id.choice4_button).setVisibility(View.GONE);
            textNum=0;
            sceneNum=12;
            questionText.setText(texts_Ice[textNum]);
        }

        private void entercaves(final String [] texts_caves){
            next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
            choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
            choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
            choice3.findViewById(R.id.choice3_button).setVisibility(View.GONE);
            choice4.findViewById(R.id.choice4_button).setVisibility(View.GONE);
            textNum=0;
            sceneNum=13;
            questionText.setText(texts_caves[textNum]);
        }





}

