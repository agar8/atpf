package android.bignerdranch.adventuretime;

import android.widget.TextView;

public class Dialogue {
    private int qResId;
    private int aResId;

    public int getaResId() {
        return this.aResId;
    }

    public void setaResId(int aResId) {
        this.aResId = aResId;
    }

    private int dID;
    public String dText;
    private String dSpeaker;
    //image


    public int getqResId() {
        return this.qResId;
    }

    public void setqResId(int qResId) {
        this.qResId = qResId;
    }

    //constructor
    public Dialogue(int dID, String qSpeaker, String qText){
        dID = dID;
        qSpeaker=qSpeaker;
        qText=qText;
    }

    public String getdText(){
        return dText;
    }
    public int getdID(){
        return dID;
    }

    public void setdID(){
        this.dID = dID;
    }
    public String getSpeaker() { return dSpeaker; }
    public void setSpeaker() { this.dSpeaker = dSpeaker; }

}
